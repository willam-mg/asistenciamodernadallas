<?php
namespace App\Helpers;

class Params 
{
    const path_server = 'https://newmodernadallas.local:8443/';
}
