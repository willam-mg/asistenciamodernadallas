<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
    <h1 class="text-center">Configuracion finalizada</h1>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
            <a href="/access" class="btn btn-success">
                Listo
            </a>
        </div>
    </div>
    
<?= $this->endSection() ?>